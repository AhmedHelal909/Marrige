<a href="{{route('dashboard.'.$module_name_plural.'.edit', $row)}}" rel="tooltip" title="" class="btn btn-warning btn-link btn-sm"
    data-original-title="@lang('site.edit') @lang('site.'.$module_name_singular)">
    <i class="fa fa-edit">@lang('site.edit')</i>
</a>