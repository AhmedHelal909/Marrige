<a href="<?php echo e(route('dashboard.'.$module_name_plural.'.edit', $row)); ?>" rel="tooltip" title="" class="btn btn-warning btn-link btn-sm"
    data-original-title="<?php echo app('translator')->get('site.edit'); ?> <?php echo app('translator')->get('site.'.$module_name_singular); ?>">
    <i class="fa fa-edit"><?php echo app('translator')->get('site.edit'); ?></i>
</a><?php /**PATH F:\Laravel Projects\Mawada\resources\views/dashboard/buttons/edit.blade.php ENDPATH**/ ?>