

<?php $__env->startSection('title', __('site.' . $module_name_plural . '.add')); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">

            <h1><?php echo app('translator')->get('site.add'); ?></h1>

            <ol class="breadcrumb">
                <li> <a href="#"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('site.dashboard'); ?></a></li>
                <li> <a href="<?php echo e(route('dashboard.' . $module_name_plural . '.index')); ?>"><i class="fa fa-archive"></i>
                        <?php echo app('translator')->get('site.categories'); ?></a></li>
                <li class="active"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.add'); ?></li>
            </ol>
        </section>

        <section class="content">

            <div class="box box-primary">

                <div class="box-header with-border">
                    <h1 class="box-title"> <?php echo app('translator')->get('site.add'); ?></h1>
                </div> 

                <div class="box-body">

                    
                    <form action="<?php echo e(route('dashboard.' . $module_name_plural . '.store')); ?>" method="post"
                        enctype="multipart/form-data">

                        <?php echo e(method_field('post')); ?>


                        <?php echo $__env->make('dashboard.'.$module_name_plural.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i>
                                <?php echo app('translator')->get('site.add'); ?></button>
                        </div>

                    </form> 

                </div> 

            </div> 

        </section><!-- end of content -->

    </div><!-- end of content wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\Hiring Applications\Hiring-application\resources\views/dashboard/categories/create.blade.php ENDPATH**/ ?>