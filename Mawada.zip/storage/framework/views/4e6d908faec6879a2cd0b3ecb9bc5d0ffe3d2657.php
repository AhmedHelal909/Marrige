

<?php $__env->startSection('title', __('site.' . $module_name_plural)); ?>


<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">

            <h1><?php echo app('translator')->get('site.'.$module_name_plural); ?></h1>

            <ol class="breadcrumb">
                <li> <a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> <?php echo app('translator')->get('site.dashboard'); ?></a>
                </li>
                <li class="active"><i class="fa fa-category"></i> <?php echo app('translator')->get('site.'.$module_name_plural); ?></li>
            </ol>
        </section>

        <section class="content">

            <div class="box box-primary">

                <div class="box-header with-border">
                    <h1 class="box-title"> <?php echo app('translator')->get('site.'.$module_name_plural); ?> <small><?php echo e($rows->total()); ?></small></h1>

                    <form action="<?php echo e(route('dashboard.' . $module_name_plural . '.index')); ?>" method="get">

                        <div class="row">

                            <div class="col-md-4">
                                <input type="text" name="search" value="<?php echo e(request()->search); ?>" class="form-control"
                                    placeholder="<?php echo app('translator')->get('site.search'); ?>">
                            </div>

                            <div class="col-md-4">
                                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i>
                                    <?php echo app('translator')->get('site.search'); ?></button>
                                    <?php if(auth()->user()->hasPermission('create-'.$module_name_plural)): ?>
                                    <a href="<?php echo e(route('dashboard.' . $module_name_plural . '.create')); ?>"
                                    class="btn btn-primary"><i class="fa fa-plus"></i> <?php echo app('translator')->get('site.add'); ?></a>
                                    <?php else: ?>
                                        <button disabled>add </button>
                                    <?php endif; ?>


                            </div>
                        </div>
                    </form>
                </div> 

                <div class="box-body">

                    <?php if($rows->count() > 0): ?>

                        <table class="table table-hover">

                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo app('translator')->get('site.fullName'); ?></th>
                                    <th><?php echo app('translator')->get('site.email'); ?></th>
                                    <th><?php echo app('translator')->get('site.university'); ?></th>
                                    <th><?php echo app('translator')->get('site.graduation_year'); ?></th>
                                    <th><?php echo app('translator')->get('site.action'); ?></th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($row->fullName); ?></td>
                                        <td><?php echo e($row->email); ?></td>
                                        <td><?php echo e($row->university); ?></td>
                                        <td><?php echo e($row->graduation_year); ?></td>
                                        <td>
                                            <?php if(auth()->user()->hasPermission('update-'.$module_name_plural)): ?>
                                                <?php echo $__env->make('dashboard.buttons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php else: ?>
                                                <input type="submit" value="edit" disabled>
                                            <?php endif; ?>

                                            <?php if(auth()->user()->hasPermission('delete-'.$module_name_plural)): ?>
                                            <?php echo $__env->make('dashboard.buttons.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php else: ?>
                                                <input type="submit" value="delete" disabled>
                                            <?php endif; ?>
                                            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal<?php echo e($row->id); ?>"><?php echo app('translator')->get('site.details'); ?></button>
                                            <!-- start popoup -->
                                            <div id="myModal<?php echo e($row->id); ?>" class="modal fade" role="dialog">
                                                <div class="modal-dialog">

                                                    <!-- Modal content-->
                                                    <div class="modal-content">
                                                    <div class="modal-header bg-info">
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title"><?php echo e($row->fullName); ?></h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <!-- start conetent -->
                                                        <div class="panel card-primary">
                                                            <!-- <div class="card-header">
                                                                <h3 class="card-title">Ribbons</h3>
                                                            </div> -->
                                                            <!-- /.card-header -->
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-sm-6">
                                                                        <div class="position-relative p-3 bg-gray" style="height: 180px">
                                                                        <div class="ribbon-wrapper">
                                                                            <div class="ribbon bg-primary" style="padding:5px 5px">
                                                                                <?php echo app('translator')->get('site.video'); ?>
                                                                            </div>
                                                                        </div>
                                                                        <video style='width:100%;height:100%;' controls>
                                                                            <source src="<?php echo e($row->video_path); ?>" type="video/mp4">
                                                                            Your browser does not support the video tag.
                                                                        </video>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <div class="position-relative p-3 bg-gray" style="height: 180px">
                                                                            <div class="ribbon-wrapper ribbon-lg">
                                                                                <div class="ribbon bg-primary" style="padding:5px 5px">
                                                                                    <?php echo app('translator')->get('site.image'); ?>
                                                                                </div>
                                                                            </div>
                                                                            <img src="<?php echo e($row->image_path); ?>" alt="no image" style='width:100%;height:100%'>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <div class="position-relative p-3 bg-gray" style="height: 180px">
                                                                        <div class="ribbon-wrapper">
                                                                            <div class="ribbon bg-primary" style="padding:5px 5px">
                                                                                <?php echo app('translator')->get('site.audio'); ?>
                                                                            </div>
                                                                        </div>
                                                                        <audio controls style='width:100%;height:55%;'>
                                                                            <source src="<?php echo e($row->audio_path); ?>" type="audio/ogg">
                                                                        </audio>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-6">
                                                                        <div class="position-relative p-3 bg-gray" style="height: 180px">
                                                                            <div class="ribbon-wrapper ribbon-lg">
                                                                                <div class="ribbon bg-primary" style="padding:5px 5px">
                                                                                    <?php echo app('translator')->get('site.cv'); ?>
                                                                                </div>
                                                                            </div>
                                                                            <a  class='btn btn-block btn-primary btn-lg' 
                                                                                href="<?php echo e($row->cv_path); ?>" 
                                                                                style="width: 70%;margin: auto;margin-top: 20%;"
                                                                                download><?php echo app('translator')->get('site.download'); ?>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- /.card-body -->
                                                        </div>
                                                        <!-- end content -->
                                                    </div>
`                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo app('translator')->get('site.close'); ?></button>
                                                    </div>
                                                    </div>

                                                </div>
                                                </div>
                                            <!-- end popup -->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table> 

                        <?php echo e($rows->appends(request()->query())->links()); ?>


                    <?php else: ?>
                        <tr>
                            <h4><?php echo app('translator')->get('site.no_records'); ?></h4>
                        </tr>
                    <?php endif; ?>

                </div> 

            </div> 

        </section><!-- end of content -->

    </div><!-- end of content wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Projects\Hiring Applications\Hiring-application\resources\views/dashboard/employees/index.blade.php ENDPATH**/ ?>