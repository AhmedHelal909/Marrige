<?php echo e(csrf_field()); ?>

<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.employer_id'); ?></label>
        <select name="employer_id" required class='form-control'>
            <?php $__currentLoopData = \App\Models\Employer::where('active',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($emp->id); ?>" <?php if(isset($row) && $row->employer_id==$emp->id): ?> selected  <?php endif; ?>><?php echo e($emp->company_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.job_field'); ?></label>
        <select name="category_id" required class='form-control'>
            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>" <?php if(isset($row) && $row->category_id==$cat->id): ?> selected  <?php endif; ?>><?php echo e($cat->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.choose_status'); ?></label>
        <select name="status" required class='form-control'>
            <option value="1" style='color:blue' <?php if(isset($row) && $row->status==1): ?> selected <?php endif; ?>><?php echo app('translator')->get('site.active'); ?></option>
            <option value="0" style='color:red'  <?php if(isset($row) && $row->status==0): ?> selected <?php endif; ?>><?php echo app('translator')->get('site.cancel'); ?></option>
            <option value="2" style='color:blue' <?php if(isset($row) && $row->status==2): ?> selected <?php endif; ?>><?php echo app('translator')->get('site.closed'); ?></option>
        </select>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.gender'); ?></label>
        <select name="gender" class='form-control'>
            <option value=""><?php echo app('translator')->get('site.choose_gender'); ?></option>
            <option value="0" <?php if(isset($row) && $row->gender==0): ?> selected  <?php endif; ?>><?php echo app('translator')->get('site.males'); ?></option>
            <option value="1" <?php if(isset($row) && $row->gender==1): ?> selected  <?php endif; ?>><?php echo app('translator')->get('site.females'); ?></option>
            <option value="2" <?php if(isset($row) && $row->gender==2): ?> selected  <?php endif; ?>><?php echo app('translator')->get('site.together'); ?></option>
        </select> 
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.title1'); ?></label>
        <input type="text" required class="form-control  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"
            value="<?php echo e(isset($row) ? $row->title : old('title')); ?>">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>



<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.salary'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="salary"
            value="<?php echo e(isset($row) ? $row->salary : old('salary')); ?>">
        <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>



<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.experience'); ?></label>
        <input type="number"  class="form-control  <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="experience"
            value="<?php echo e(isset($row) ? $row->experience : old('experience')); ?>">
        <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.qualification'); ?></label>
        <input type="text"  class="form-control  <?php $__errorArgs = ['qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qualification"
            value="<?php echo e(isset($row) ? $row->qualification : old('qualification')); ?>">
        <?php $__errorArgs = ['qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.interviewer_name'); ?></label>
        <input type="text" required class="form-control  <?php $__errorArgs = ['interviewer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="interviewer_name"
            value="<?php echo e(isset($row) ? $row->interviewer_name : old('interviewer_name')); ?>">
        <?php $__errorArgs = ['interviewer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.interviewer_role'); ?></label>
        <input type="text" required class="form-control  <?php $__errorArgs = ['interviewer_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="interviewer_role"
            value="<?php echo e(isset($row) ? $row->interviewer_role : old('interviewer_role')); ?>">
        <?php $__errorArgs = ['interviewer_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.note'); ?></label>
        <textarea class="form-control" name="note"><?php echo e(isset($row) ? $row->note : old('note')); ?></textarea>
        <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.details'); ?></label>
        <textarea required class="form-control" name="details"><?php echo e(isset($row) ? $row->details : old('details')); ?></textarea>
        <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php $count=0; ?>
<?php if(isset($row)): ?>
    <?php  if(isset($row)) {    $count=$row->avmeetings->where('available',1)->count(); } ?>
<?php endif; ?>
<div class="col-md-3">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.meeting_date'); ?></label>
        <input type="date"  class="form-control  <?php $__errorArgs = ['meeting_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="meeting_date"
            value="<?php echo e(isset($row) ? $row->meeting_date : old('meeting_date')); ?>" <?php if($count >0): ?> disabled <?php else: ?> required <?php endif; ?>>
        <?php $__errorArgs = ['meeting_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-md-3">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.meeting_time'); ?></label>
        <input type="number"  class="form-control  <?php $__errorArgs = ['meeting_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="meeting_time"
            value="<?php echo e(isset($row) ? $row->meeting_time : old('meeting_time')); ?>"<?php if($count >0): ?> disabled <?php else: ?> required <?php endif; ?>>
        <?php $__errorArgs = ['meeting_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    </div>
</div>

<div class="col-md-3">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.meeting_from'); ?></label>
        <input type="time"  class="form-control  <?php $__errorArgs = ['meeting_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="meeting_from"
            value="<?php echo e(isset($row) ? $row->meeting_from : old('meeting_from')); ?>" <?php if($count >0): ?> disabled <?php else: ?> required <?php endif; ?>>
        <?php $__errorArgs = ['meeting_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
    </div> 
</div>
<div class="col-md-3">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.meeting_to'); ?></label>
        <input type="time"  class="form-control  <?php $__errorArgs = ['meeting_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="meeting_to"
            value="<?php echo e(isset($row) ? $row->meeting_to : old('meeting_to')); ?>" <?php if($count >0): ?> disabled <?php else: ?> required <?php endif; ?>>
        <?php $__errorArgs = ['meeting_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
       </div> 
    </div>
</div>

<?php /**PATH F:\Laravel Projects\Hiring Applications\Hiring-application\resources\views/dashboard/jobs/form.blade.php ENDPATH**/ ?>