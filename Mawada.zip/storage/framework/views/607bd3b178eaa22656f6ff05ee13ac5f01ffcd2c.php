<?php echo e(csrf_field()); ?>

<?php
    $marrige_type = [
        'زوجة اولى',
        'زوجة ثانية',
];
$social_status = [
    'اعزب',
    'متزوج',
    'مطلق',
    'ارمل',
];
$skin_color = [
    'ابيض',
    'حنطي مائل للبياض',
    'حنطي مائل للسمار',
    'اسمر فاتح',
    'سمر غامق',
    'اسود',
];
$physique = [
    'نحيف/رفيع',
    'متوسط البنية',
    'قوام رياضي',
    'سمين',
    'غامق',
    
];
$religiosity = [
 'لست متدين',
 'متدين قليلا',
 'متدين',
 'متدين كثيرا',
 'أفضل أن لا أقول ',
];
$pray = [
    'أصلي دائما',
    'أصلي أغلب الأوقات',
    'أصلي بعض الوقت',
    'لا أصلي ',
    ' أفضل أن لاأقول',
];
$educational_equal = [
    'دراسة متوسطة',
    'دراسة ثانوية',
    'دراسة جامعية',
    'دكتوراه',
    'دراسة ذاتية',
];
$financial_status =[
    'فقير',
    'اقل من المتوسط',
    'متوسط',
    'أكثر من متوسط',
    'جيد',
    'ميسور',
    'غني',
];
$work = [
    'بدون عمل حاليا',
    'لازلت أدرس',
    'سكرتارية',
    'مجال الفن / الأدب',
    'الإدارة',
    'مجال التجارة',
    'مجال الأغذية',
    'مجال الانشاءات والبناء',
    'مجال القانون ',
    'مجال الطب ',
    'السياسة / الحكومة',
    'متقاعد',
    'التسويق والمبيعات',
    'صاحب عمل خاص',
    'مجال التدريس',
    'مجال النقل ',
    'مجال الكمبيوتر أو المعلومات / ',
    'شيء آخر',
];
$health_status = [
    'سليم والحمد لله',
    'اعاقة حركية',
    'اعاقة فكرية',
    'اكتئاب',
    'انحناء وتقوس',
    'انفصام',
    'باطنية',
    'برص',
    'بصرية',
    'بهاق',
    'جلدية',
    'حروق مشوهة',
    'سكري',
    'سمعية',
    'كلامية - نطق',
    'سمية مفرطة',
    'شلل أطفال',
    'شلل رباعي',
    'شلل نصفي',
    'صدفية',
    'صرع',
    'عجز جنسي',
    'عقم',
    ' فقدان طرف أو عضو',
    'متلازمة داون',
    'نفسية',
  
];
$monthly_income = [
    'بدون دخل',
    'أقل من 500 جنيه',
    '500-1000 جنيه',
    '1000-3000 جنيه',
    '3000-6000 جنيه',
    '6000-9000 جنيه',
    '9000-12000 جنيه',
    '12000-16000 جنيه',
    '16000-20000 جنيه',
    'أكثر من 20000 جنيه',
    'لا أحب ان أقول',
];
?>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.user_name'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username"
            value="<?php echo e(isset($row) ? $row->user_name : old('user_name')); ?>">
        <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.password'); ?></label>
        <input type="password" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" value="">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.password_confirmation'); ?></label>
        <input type="password" class="form-control  <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            name="password_confirmation" value="">
        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.email'); ?></label>
        <input type="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
            value="<?php echo e(isset($row) ? $row->email : old('email')); ?>">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.nationality'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username"
            value="<?php echo e(isset($row) ? $row->nationality : old('nationality')); ?>">
        <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.country'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country"
            value="<?php echo e(isset($row) ? $row->country : old('country')); ?>">
        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>




<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.city'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city"
            value="<?php echo e(isset($row) ? $row->city : old('city')); ?>">
        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.marrige_type'); ?></label>
        <select name="marrige_type" class='form-control'>
            
                <option value="اختار نوع الزوجة"> 
                    اختار نوع الزوجة
                </option>
                <?php $__currentLoopData = $marrige_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->marrige_type==$index): ?> selected <?php endif; ?>><?php echo e($type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              
        </select>
        <?php $__errorArgs = ['marrige_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.social_status'); ?></label>
        <select name="social_status" class='form-control'>
            
                <option > 
                    اختار الحالة الاجتماعية
                </option>
                <?php $__currentLoopData = $social_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->social_status==$index): ?> selected <?php endif; ?>><?php echo e($social); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
              
        </select>
        <?php $__errorArgs = ['social_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.age'); ?></label>
        <select name="age" class='form-control'>
            <option > 
                اختار العمر 
            </option>
            <?php for($i=21;$i<=90;$i++): ?>
                <option value="<?php echo e($i); ?>" <?php if(isset($row) && $row->age==$i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
            <?php endfor; ?>    
        </select>
        <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.child_no'); ?></label>
        <select name="child_no" class='form-control'>
            <option > 
                اختار عدد الاطفال 
            </option>
            <?php for($i=0;$i<=8;$i++): ?>
                <option value="<?php echo e($i); ?>" <?php if(isset($row) && $row->child_no==$i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
            <?php endfor; ?>    
        </select>
        <?php $__errorArgs = ['child_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.weight'); ?></label>
        <select name="weight" class='form-control'>
            <option > 
                ماهو وزنك   
            </option>
            <?php for($i=30;$i<=160;$i++): ?>
                <option value="<?php echo e($i); ?>" <?php if(isset($row) && $row->weight==$i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
            <?php endfor; ?>    
        </select>
        <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.height'); ?></label>
        <select name="height" class='form-control'>
            <option > 
                ماهو طولك   
            </option>
            <?php for($i=130;$i<=225;$i++): ?>
                <option value="<?php echo e($i); ?>" <?php if(isset($row) && $row->height==$i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
            <?php endfor; ?>    
        </select>
        <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.skin_color'); ?></label>
        <select name="skin_color" class='form-control'>
            <option > 
                اختار لون البشرة  
            </option>
        </option>
        <?php $__currentLoopData = $skin_color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$skin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->skin_color==$index): ?> selected <?php endif; ?>><?php echo e($skin); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['skin_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.physique'); ?></label>
        <select name="physique" class='form-control'>
            <option > 
                بنية الجسم    
            </option>
            <?php $__currentLoopData = $physique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$phy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->physique==$index): ?> selected <?php endif; ?>><?php echo e($phy); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </select>
        <?php $__errorArgs = ['physique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.religiosity'); ?></label>
        <select name="religiosity" class='form-control'>
            <option > 
                --اختر--     
            </option>
            <?php $__currentLoopData = $religiosity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$relig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->religiosity==$index): ?> selected <?php endif; ?>><?php echo e($relig); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['religiosity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.pray'); ?></label>
        <select name="pray" class='form-control'>
            <option > 
                --اختر--     
            </option>
            <?php $__currentLoopData = $pray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$pray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->pray==$index): ?> selected <?php endif; ?>><?php echo e($pray); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
        <?php $__errorArgs = ['pray'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.smoke'); ?></label>
        <select name="smoke" class='form-control'>
            <option > 
                --اختر--     
            </option>
            <option value="1" <?php if(isset($row) && $row->smoke==1): ?> selected <?php endif; ?>>لا</option>
            <option value="2" <?php if(isset($row) && $row->smoke==2): ?> selected <?php endif; ?>>نعم</option>
        </select>
        <?php $__errorArgs = ['smoke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.beard'); ?></label>
        <select name="beard" class='form-control'>
            <option > 
                --اختر--     
            </option>
            <option value="0" <?php if(isset($row) && $row->beard==1): ?> selected <?php endif; ?>>لا</option>
            <option value="1" <?php if(isset($row) && $row->beard==2): ?> selected <?php endif; ?>>نعم</option>
        </select>
        <?php $__errorArgs = ['beard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.educational_equal'); ?></label>
        <select name="educational_equal" class='form-control'>
            <option > 
              اختار المؤهل التعليمي    
            </option>
            <?php $__currentLoopData = $educational_equal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$educational_equal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->educational_equal==$index): ?> selected <?php endif; ?>><?php echo e($educational_equal); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['educational_equal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.financial_status'); ?></label>
        <select name="financial_status" class='form-control'>
            <option > 
            وضعك المادي    
            </option>
            <?php $__currentLoopData = $financial_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$financial_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->financial_status==$index): ?> selected <?php endif; ?>><?php echo e($financial_status); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </select>
        <?php $__errorArgs = ['financial_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.work'); ?></label>
        <select name="work" class='form-control'>
            <option > 
            وضعك المادي    
            </option>
            <?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->work==$index): ?> selected <?php endif; ?>><?php echo e($work); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['work'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.job'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="job"
            value="<?php echo e(isset($row) ? $row->job : old('job')); ?>">
        <?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.health_status'); ?></label>
        <select name="health_status" class='form-control'>
            <option > 
            وضعك المادي    
            </option>
            <?php $__currentLoopData = $health_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$health_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->health_status==$index): ?> selected <?php endif; ?>><?php echo e($health_status); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </select>
        <?php $__errorArgs = ['health_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.monthly_income'); ?></label>
        <select name="monthly_income" class='form-control'>
            <option > 
            دخلك الشهري 
            </option>
            <?php $__currentLoopData = $monthly_income; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$monthly_income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($index); ?>" <?php if(isset($row) && $row->monthly_income==$index): ?> selected <?php endif; ?>><?php echo e($monthly_income); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            
        </select>
        <?php $__errorArgs = ['monthly_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-md-2"></div>
<div class="form-group">
    <label for="exampleFormControlTextarea1">مواصفات شريكك</label>
    <textarea class="form-control" id="partner_specification" rows="3"  <?php $__errorArgs = ['partner_specification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="partner_specification" 
    value="<?php echo e(isset($row) ? $row->partner_specification : old('partner_specification')); ?>"
    ></textarea>
    <?php $__errorArgs = ['partner_specification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
    
</div>
<div class="col-md-2"></div>
<div class="form-group">
    <label for="exampleFormControlTextarea1">تحدث عن نفسك</label>
    <textarea class="form-control" id="self_description" rows="3"  <?php $__errorArgs = ['self_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="self_description" 
    value="<?php echo e(isset($row) ? $row->self_description : old('self_description')); ?>"
    ></textarea>
    <?php $__errorArgs = ['self_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
    
</div>

<div class="col-md-4">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.fullname'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fullname"
            value="<?php echo e(isset($row) ? $row->fullname : old('fullname')); ?>">
        <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-4">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.phone'); ?></label>
        <input type="text" class="form-control  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
            value="<?php echo e(isset($row) ? $row->phone : old('phone')); ?>">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-4">
    <div class="form-group">
        <label><?php echo app('translator')->get('site.image'); ?></label>
        <input type="file" name="image" class="form-control  <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>





<?php /**PATH F:\Laravel Projects\Mawada\resources\views/dashboard/husbands/form.blade.php ENDPATH**/ ?>