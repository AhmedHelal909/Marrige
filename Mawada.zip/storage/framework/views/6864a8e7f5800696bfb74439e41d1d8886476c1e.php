<header class="main-header">

    
    <a href="#" class="logo">
        
        <span class="logo-mini">Hiring</span>
        <span class="logo-lg">Hiring</span>
    </a>

    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">

                <!-- Messages: style can be found in dropdown.less-->
                

                
                

                <li class="dropdown tasks-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-flag-o"></i></a>
                    <ul class="dropdown-menu">
                        <li>
                            <ul class="menu">

                                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                            <?php echo e($properties['native']); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>
                    </ul>
                </li>

                
                <li class="dropdown user user-menu">

                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
                        <img src=" <?php echo e(auth()->user()->image_path); ?>" class="user-image" alt="User Image">
                        <span class="hidden-xs"><?php echo e(auth()->user()->name); ?></span>
                    </a>
                    <ul class="dropdown-menu">

                        
                        <li class="user-header">
                            <img src="<?php echo e(auth()->user()->image_path); ?>" class="img-circle" alt="User Image">

                            <p>
                                <?php echo e(auth()->user()->name); ?>

                            </p>
                        </li>

                        
                        <li class="user-footer">


                            <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat" onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();"><?php echo app('translator')->get('site.logout'); ?></a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>

                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

</header><?php /**PATH F:\Laravel Projects\Hiring Applications\Hiring-application\resources\views/dashboard/layouts/_navbar.blade.php ENDPATH**/ ?>