<aside class="main-sidebar">

    <section class="sidebar">

        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(auth()->user()->image_path); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(auth()->user()->name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> <?php echo app('translator')->get('site.statue'); ?></a>
            </div>
        </div>

        <ul class="sidebar-menu" data-widget="tree">

            <li><a href="<?php echo e(route('dashboard.home')); ?>"><i
                        class="fa fa-th"></i><span><?php echo app('translator')->get('site.dashboard'); ?></span></a></li>

           
            <?php if(auth()->user()->hasPermission('read-users')): ?>
            <li><a href="<?php echo e(route('dashboard.users.index')); ?>"><i
                        class="fa fa-user"></i><span><?php echo app('translator')->get('site.users'); ?></span></a></li>
            <?php endif; ?>

            <?php if(auth()->user()->can('read-roles')): ?>
                   <li><a href="<?php echo e(route('dashboard.roles.index')); ?>"><i
                        class="fa fa-hourglass-half"></i><span><?php echo app('translator')->get('site.roles'); ?></span></a></li>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('read-categories')): ?>
            <li><a href="<?php echo e(route('dashboard.categories.index')); ?>"><i
                        class="fa fa-tasks"></i><span><?php echo app('translator')->get('site.categories'); ?></span></a></li>
            <?php endif; ?>

            <?php if(auth()->user()->hasPermission('read-employees')): ?>
            <li><a href="<?php echo e(route('dashboard.employees.index')); ?>"><i
                        class="fa fa-users"></i><span><?php echo app('translator')->get('site.employees'); ?></span></a></li>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('read-employers')): ?>
            <li><a href="<?php echo e(route('dashboard.employers.index')); ?>"><i
                        class="fa fa-home"></i><span><?php echo app('translator')->get('site.employers'); ?></span></a></li>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('read-jobs')): ?>
            <li><a href="<?php echo e(route('dashboard.jobs.index')); ?>"><i
                        class="fa fa-list"></i><span><?php echo app('translator')->get('site.jobs'); ?></span></a></li>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('read-EmployeeJobs')): ?>
            <li><a href="<?php echo e(route('dashboard.EmployeeJobs.index')); ?>"><i
                        class="fa fa-list"></i><span><?php echo app('translator')->get('site.EmployeeJobs'); ?></span></a></li>
            <?php endif; ?>





        </ul>

    </section>

</aside>
<?php /**PATH F:\Laravel Projects\Hiring Applications\Hiring-application\resources\views/dashboard/layouts/_aside.blade.php ENDPATH**/ ?>