<form action="<?php echo e(route('dashboard.'.$module_name_plural.'.destroy', $row)); ?>" method="POST" style="display: inline-block">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>

    <button type="submit" rel="tooltip" title="" class="btn btn-danger btn-link btn-sm delete" data-original-title="<?php echo app('translator')->get('site.delete'); ?>">
        <i class="fa fa-1x fa-trash"> <?php echo app('translator')->get('site.delete'); ?></i>
    </button> 
    
</form>
    
<?php /**PATH F:\Laravel Projects\Mawada\resources\views/dashboard/buttons/delete.blade.php ENDPATH**/ ?>